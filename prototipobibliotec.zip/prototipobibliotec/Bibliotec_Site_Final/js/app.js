function toggleMenu() {
  const nav = document.querySelector('.nav');

  if (!nav) return;

  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  nav.style.position = 'absolute';
  nav.style.top = '84px';
  nav.style.left = '0';
  nav.style.right = '0';
  nav.style.background = 'var(--paper)';
  nav.style.padding = '20px 6%';
  nav.style.flexDirection = 'column';
}

function toggleFavorite(btn) {
  btn.classList.toggle('saved');
  btn.innerHTML = btn.classList.contains('saved')
    ? '♥ Favoritado'
    : '♡ Favoritar';
}

function toggleTheme() {
  document.body.classList.toggle('dark');
}

function fakeSubmit(e) {
  e.preventDefault();
  alert('Protótipo: aqui o Flask receberá os dados do formulário.');
}

const search = document.getElementById('catalogSearch');

if (search) {
  search.addEventListener('input', () => {
    const q = search.value.toLowerCase();

    document.querySelectorAll('.book-card').forEach(c => {
      c.style.display = c.innerText.toLowerCase().includes(q)
        ? 'block'
        : 'none';
    });
  });
}
